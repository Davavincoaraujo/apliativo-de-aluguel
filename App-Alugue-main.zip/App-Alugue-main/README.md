# App-Alugue
![WhatsApp Image 2021-11-30 at 11 40 00 (2)](https://user-images.githubusercontent.com/94018817/144067871-9f3c052c-f288-46a2-8444-56c11c6aa5f3.jpeg)
![WhatsApp Image 2021-11-30 at 11 40 00 (1)](https://user-images.githubusercontent.com/94018817/144067878-f05e5cce-66c5-4854-a112-2f756a395194.jpeg)
![WhatsApp Image 2021-11-30 at 11 40 00](https://user-images.githubusercontent.com/94018817/144067880-9bf0d5ca-0b87-4c8d-a424-a140059dddd0.jpeg)

Esse projeto foi desenvolvido com as seguintes tecnologias:

Node.js
React
React Native
Expo

Projeto
O app Alugue é um aplicativo de sistema de reserva de hotéis e casas contendo um menu drawer que acessa as paginas de detalhes das casas e hoteis
